package com.ms4systems.devs.extensions;

public interface ProvidesTooltip {
	String getTooltip();
}
