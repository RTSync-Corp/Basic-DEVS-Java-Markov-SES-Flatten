package com.ms4systems.devs.exception;

public class InputSynchronizationException extends DEVSRuntimeException {
	private static final long serialVersionUID = 1L;

	public InputSynchronizationException(String message) {
		super(message);
	}
}
