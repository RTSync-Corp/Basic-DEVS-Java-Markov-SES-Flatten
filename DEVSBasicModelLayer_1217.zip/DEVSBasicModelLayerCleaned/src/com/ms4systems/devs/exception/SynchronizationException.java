package com.ms4systems.devs.exception;

public class SynchronizationException extends DEVSRuntimeException {
	private static final long serialVersionUID = 1L;

	public SynchronizationException(String message) {
		super(message);
	}
}
