package com.ms4systems.devs.exception;

public class AccessException extends DEVSRuntimeException {
	private static final long serialVersionUID = 1L;

	public AccessException(String message) {
		super(message);
	}
}
