package com.ms4systems.devs.exception;

public class InvalidUsageException extends DEVSRuntimeException {
	private static final long serialVersionUID = 1L;

	public InvalidUsageException(String message) {
		super(message);
	}
}
