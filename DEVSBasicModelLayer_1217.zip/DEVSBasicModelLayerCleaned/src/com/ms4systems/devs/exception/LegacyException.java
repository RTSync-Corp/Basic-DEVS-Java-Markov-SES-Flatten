package com.ms4systems.devs.exception;

public class LegacyException extends DEVSRuntimeException {
	private static final long serialVersionUID = 1L;

	public LegacyException(String message) {
		super(message);
	}
}
