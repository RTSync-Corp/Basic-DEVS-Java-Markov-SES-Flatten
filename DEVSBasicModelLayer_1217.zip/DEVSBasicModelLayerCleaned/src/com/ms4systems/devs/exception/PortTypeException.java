package com.ms4systems.devs.exception;

public class PortTypeException extends DEVSRuntimeException {
	private static final long serialVersionUID = 1L;

	public PortTypeException(String message) {
		super(message);
	}
}
